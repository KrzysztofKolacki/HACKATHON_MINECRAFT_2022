module DigitConverter {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.swing;
    requires java.naming;

    requires com.jfoenix;
    requires slf4j.api;
    requires slf4j.simple;

}