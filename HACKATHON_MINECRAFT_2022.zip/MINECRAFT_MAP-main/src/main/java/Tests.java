import net.morbz.minecraft.blocks.SimpleBlock;

public class Tests {
    public static void main(String[] args) {
        System.out.println(SimpleBlock.SLIME_BLOCK.getBlockId());
        System.out.println(SimpleBlock.SLIME_BLOCK.getBlockData());
        System.out.println(SimpleBlock.SLIME_BLOCK.getTransparency());
    }
}
