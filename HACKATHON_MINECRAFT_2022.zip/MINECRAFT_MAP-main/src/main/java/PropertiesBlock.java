import ConvexHull.Point3d;
import net.morbz.minecraft.blocks.*;

import javax.print.DocFlavor;
import java.awt.*;
import java.util.*;
import java.util.List;

public class PropertiesBlock {
    public int r;
    public int g;
    public int b;
    public double iii;
    public double classificationMax;
    public Map<Double, Integer> compositions;
    public Color averageColor;

    public PropertiesBlock() {
        r = 0;
        g = 0;
        b = 0;
        iii = 0;
        compositions = new HashMap<>();

    }

    public void findClassificationMax() {
        int maxCount = -10;
        int size = 0;
        for (Map.Entry<Double, Integer> xd : compositions.entrySet()) {
            if (xd.getValue() > maxCount) {
                maxCount = xd.getValue();
                classificationMax = xd.getKey();

            }
            size += xd.getValue();

        }

        //System.out.println(r);
       // System.out.println(g);
        //System.out.println(b);
        //System.out.println(size);
        iii = iii / size;
        averageColor = new Color(r / size, g / size, b / size);
        

    }

    @Override
    public String toString() {
        StringBuilder string = new StringBuilder();
        for (Map.Entry<Double, Integer> xd : compositions.entrySet()) {
            string.append(xd.getKey()).append(" ").append(xd.getValue()).append(" ");
        }
        return string.toString() + averageColor + " " + getHue() + " " + iii;

    }
    static Random random = new Random();

    static IBlock randomBlock() {
        IBlock[] plants = new IBlock[] {
                SimpleBlock.MELON_BLOCK,
                SimpleBlock.YELLOW_FLOWER, SimpleBlock.RED_FLOWER,
                new CustomBlock(31, 1, 1), new CustomBlock(31, 1, 1),
                new CustomBlock(31, 1, 1), new CustomBlock(31, 1, 1),
                new CustomBlock(31, 1, 1), new CustomBlock(31, 1, 1),
                new CustomBlock(31, 1, 1), new CustomBlock(31, 1, 1),
                new CustomBlock(31, 1, 1), new CustomBlock(31, 1, 1),
                SimpleBlock.AIR, SimpleBlock.AIR, SimpleBlock.AIR, SimpleBlock.AIR, SimpleBlock.AIR, SimpleBlock.AIR,
                new CustomBlock(175, 2, 1), new CustomBlock(175, 2, 1),
                new CustomBlock(175, 3, 1), new CustomBlock(175, 3, 1),
                new CustomBlock(31, 1, 1), new CustomBlock(31, 1, 1),
                new CustomBlock(31, 1, 1), new CustomBlock(31, 1, 1),
                new CustomBlock(31, 1, 1), new CustomBlock(31, 1, 1),
                new CustomBlock(31, 1, 1), new CustomBlock(31, 1, 1),
                new CustomBlock(31, 1, 1), new CustomBlock(31, 1, 1),
                SimpleBlock.AIR, SimpleBlock.AIR, SimpleBlock.AIR, SimpleBlock.AIR, SimpleBlock.AIR, SimpleBlock.AIR,
                new CustomBlock(175, 2, 1), new CustomBlock(175, 2, 1),
                new CustomBlock(175, 3, 1), new CustomBlock(175, 3, 1)

        };
        return plants[random.nextInt(plants.length)];

    }

    static IBlock randomRoof() {
        IBlock[] roofs = new IBlock[] {
                new CustomBlock(44, 4, 0),
                new CustomBlock(44, 4, 0),
                SimpleBlock.BRICK_BLOCK

        };
        return roofs[random.nextInt(roofs.length)];

    }

    public float getHue() {
        float[] xxx = new float[3];
        Color.RGBtoHSB(averageColor.getRed(), averageColor.getGreen(), averageColor.getBlue(), xxx);
        return xxx[0];

    }

}
