package ConvexHull;

import java.util.Locale;

public class Point3d extends Vector3d {
    public double iii;
    public Point3d() {
    }

    public Point3d(
            double x,
            double y,
            double z,
            Integer r,
            Integer g,
            Integer b,
            double iii,
            double c
    ) {


        set(
                x,
                y,
                z,
                r,
                g,
                b,
                c
        );
        this.iii = iii;


    }

    @Override
    public String toString() {
        return String.format(Locale.US,"%f %f %f %d %d %d %f %f",  x, y, z, r, g, b, iii, c);

    }

}
