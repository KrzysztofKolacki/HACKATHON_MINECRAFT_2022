import java.io.*;
import java.util.*;

import ConvexHull.Point3d;
import ConvexHull.ConvexHull3D;
import Octree.AABB;
import Octree.Cube3d;
import Octree.Octree;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Point3D;
import javafx.geometry.Rectangle2D;
import javafx.scene.*;
import javafx.scene.paint.Color;
import javafx.scene.image.Image;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Box;
import javafx.scene.shape.Shape3D;
import javafx.scene.transform.Affine;
import javafx.scene.transform.Rotate;
import javafx.stage.Screen;
import javafx.stage.Stage;
import jdk.nashorn.api.tree.BlockTree;
import jdk.nashorn.api.tree.Tree;
import net.morbz.minecraft.blocks.*;
import net.morbz.minecraft.blocks.states.Facing4State;
import net.morbz.minecraft.level.FlatGenerator;
import net.morbz.minecraft.level.GameType;
import net.morbz.minecraft.level.IGenerator;
import net.morbz.minecraft.level.Level;
import net.morbz.minecraft.world.DefaultLayers;
import net.morbz.minecraft.world.World;

public class ExportService extends Service<Void> {

    private Boolean currentState;
    private ObjectProperty<String> currentWork = new SimpleObjectProperty<>();
    private List<File> files;
    private long pointsCount;
    private long pointsExportCount;

    private List<Point3d> points3dList;
    private Map<Vector3MM, PropertiesBlock> points3mmProperties;
    private List<Cube3d> cube3dList;
    private List<Cube3d> cube3dListNew;
    //    private List<Cube3d> cube3dListLocalTemp;
//    private List<Cube3d> cube3dListLocal;
    private Point3d[] vertices;
    private Octree octree;
    private int counter = 0;
    private long max = 0;

    private final Stage cubesStage = new Stage();

    Group root = new Group();
    XformBox cameraXform = new XformBox();
    XformBox allXForm = new XformBox();
    PhongMaterial redMaterial, greenMaterial, blueMaterial;

    PerspectiveCamera camera = new PerspectiveCamera(true);

    private static double CAMERA_INITIAL_DISTANCE = -450;
    private static double CAMERA_INITIAL_X_ANGLE = -10.0;
    private static double CAMERA_INITIAL_Y_ANGLE = 0.0;
    private static double CAMERA_NEAR_CLIP = 0.1;
    private static double CAMERA_FAR_CLIP = 10000.0;
    private static double AXIS_LENGTH = 1000.0;
    private static double MOUSE_SPEED = 0.1;
    private static double ROTATION_SPEED = 2.0;

    double mouseStartPosX, mouseStartPosY;
    double mousePosX, mousePosY;
    double mouseOldX, mouseOldY;
    double mouseDeltaX, mouseDeltaY;

    private void handleMouse(Scene scene) {

        scene.setOnScroll(me -> {
            camera.setTranslateZ(camera.getTranslateZ() + me.getDeltaY());
        });

        scene.setOnMousePressed(me -> {
            mouseStartPosX = me.getSceneX();
            mouseStartPosY = me.getSceneY();
            mousePosX = me.getSceneX();
            mousePosY = me.getSceneY();
            mouseOldX = me.getSceneX();
            mouseOldY = me.getSceneY();
        });

        scene.setOnMouseDragged(me -> {
            mouseOldX = mousePosX;
            mouseOldY = mousePosY;
            mousePosX = me.getSceneX();
            mousePosY = me.getSceneY();
            mouseDeltaX = (mousePosX - mouseOldX);
            mouseDeltaY = (mousePosY - mouseOldY);

            if (me.isPrimaryButtonDown()) {
                allXForm.addRotation(-mouseDeltaX * MOUSE_SPEED * ROTATION_SPEED, Rotate.Y_AXIS);
                allXForm.addRotation(mouseDeltaY * MOUSE_SPEED * ROTATION_SPEED, Rotate.X_AXIS);
            }
        });
    }

    private void handleKeyboard(Scene scene) {
        scene.setOnKeyPressed(event -> allXForm.reset());
    }

    PhongMaterial createMaterial(Color diffuseColor, Color specularColor) {
        PhongMaterial material = new PhongMaterial(diffuseColor);
        material.setSpecularColor(specularColor);
        return material;
    }

    class XformBox extends Group {
        XformBox() {
            super();
            getTransforms().add(new Affine());
        }

        public void addRotation(double angle, Point3D axis) {
            Rotate r = new Rotate(angle, axis);
            getTransforms().set(0, r.createConcatenation(getTransforms().get(0)));
        }

        public void reset() {
            getTransforms().set(0, new Affine());
        }
    }

    @Override
    protected Task<Void> createTask() {
        return new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                Platform.runLater(
                        () -> {
                            setCurrentWork("Start");
                        }
                );

                points3dList = new ArrayList<Point3d>();
                points3mmProperties = new HashMap<>();
                counter = 0;
                currentState = true;

                // ilosc operacji do progressu
                max = pointsCount;

                try {

                    for (File file : files) {

                        BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
                        String row;

                        Platform.runLater(
                                () -> {
                                    setCurrentWork("1 z 4: Dekodowanie plikow...");
                                }
                        );

                        // pomijamy naglowek

                        bufferedReader.readLine();
                        while ((row = bufferedReader.readLine()) != null) {
                            if (!currentState) return null;

                            try {


                                String[] pointArray = new String[10];
                                pointArray = row.split(",");

                                Point3d point3d = new Point3d();
                                point3d.x = Double.parseDouble(pointArray[0]);  // x
                                point3d.y = Double.parseDouble(pointArray[1]);  // y
                                point3d.z = Double.parseDouble(pointArray[2]) + 90.0;  // z
                                point3d.r = Integer.parseInt(pointArray[3]);    // Red
                                point3d.g = Integer.parseInt(pointArray[4]);    // Green
                                point3d.b = Integer.parseInt(pointArray[5]);    // Blue
                                point3d.iii = Double.parseDouble(pointArray[8]); // intensity
                                point3d.c = Double.parseDouble(pointArray[9]);  // classification
                                points3dList.add(point3d);

                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            counter++;
                            updateProgress(counter, max);
                        }

                    }
                    System.out.println("Prawidlowych pkt: " + points3dList.size());

                } catch (Exception e) {
                    e.printStackTrace();
                }



                try {
                    Platform.runLater(
                            () -> {
                                setCurrentWork("2 z 4: zadanie");
                            }
                    );

                    for (Point3d point : points3dList) {
                        point.x = Math.floor(point.x);
                        point.y = Math.floor(point.y);
                        point.z = Math.floor(point.z);

                        Vector3MM vector3mm = new Vector3MM(point.x, point.y, point.z);
                        // System.out.println(vector3mm);



                        if (points3mmProperties.containsKey(vector3mm)) {
                            PropertiesBlock pb = points3mmProperties.get(vector3mm);
                            pb.r += point.r;
                            pb.g += point.g;
                            pb.b += point.b;
                            pb.iii += point.iii;
                            if (pb.compositions.containsKey(point.c)) {
                                int buffer = pb.compositions.get(point.c) + 1;
                                pb.compositions.put(point.c, buffer );
                            }
                            else {
                                pb.compositions.put(point.c, 1);
                            }
                            //System.out.println("Constains!");

                        }
                        else {
                            PropertiesBlock pb = new PropertiesBlock();
                            pb.iii += point.iii;
                            pb.r += point.r;
                            pb.g += point.g;
                            pb.b += point.b;
                            pb.compositions.put(point.c, 1);
                            points3mmProperties.put(vector3mm, pb);
                            //System.out.println("Does not contain!");

                        }

                    }


                } catch (Exception e) {
                    e.printStackTrace();
                }


                try {
                    Platform.runLater(
                            () -> {
                                setCurrentWork("3 z 4: zadanie ...");
                            }
                    );

                    //zadanie
                    double iiiMax = Double.MIN_VALUE;
                    double iiiMin = Double.MAX_VALUE;

                    for (Vector3MM vector3mm : points3mmProperties.keySet()) {
                        if (vector3mm.z >= 0 && vector3mm.z <= 255) {
                            PropertiesBlock bp = points3mmProperties.get(vector3mm);
                            bp.findClassificationMax();
                            System.out.println(vector3mm + " " + bp);

                            iiiMax = Math.max(iiiMax, bp.iii);
                            iiiMin = Math.min(iiiMin, bp.iii);

                        }

                    }

                    System.out.println("MINIMUM = " + iiiMin);
                    System.out.println("MAXIMUM = " + iiiMax);











                } catch (Exception e) {
                    e.printStackTrace();
                }





                try {
                    Platform.runLater(
                            () -> {
                                setCurrentWork("4 z 4: rozklad chmury do mapy...");
                            }
                    );



                    DefaultLayers layers = new DefaultLayers();
                    layers.setLayer(0, Material.BEDROCK);
                    IGenerator generator = new FlatGenerator(layers);
                    Level level = new Level("HackathonMap", generator);
                    level.setGameType(GameType.CREATIVE);
                    level.setAllowCommands(true);

                    World world = new World(level, layers);

                    // Create a huge structure of glass that has an area of 100x100 blocks and is 50 blocks height.
                    // On top of the glass structure we have a layer of grass.
                    level.setSpawnPoint(525669, 200, 699455);

                    for (int x = 525498; x < 526011; x++) {
                        for (int z = 699175; z < 699758; z++) {
                            for (int y = 80; y < 84; y++) {
                                world.setBlock(x, y, z, DirtBlock.DIRT);

                            }

                        }

                    }
                    for (int x = 525500; x < 526009; x++) {
                        for (int z = 699175; z < 699758; z++) {
                            for (int y = 84; y < 90; y++) {
                                world.setBlock(x, y, z, SimpleBlock.WATER);

                            }

                        }

                    }


                    for (Vector3MM vector3mm : points3mmProperties.keySet()) {
                        PropertiesBlock pb = points3mmProperties.get(vector3mm);
                        if (vector3mm.z >= 0 && vector3mm.z <= 255) {
                            if (pb.classificationMax == 2.0) { // GROUND
                                //if (pb.r >= 165 && pb.r <= 210 && pb.g >= 170 && pb.g <= 210 && pb.b >= 155 && pb.b <= 175 &&
                                //true)
                                if (pb.iii <= 31000) {
                                    world.setBlock(vector3mm.x, vector3mm.z, vector3mm.y, new CustomBlock(251, 7, 0));
                                    for (int i = 84; i < vector3mm.z; ++i) {
                                        world.setBlock(vector3mm.x, i, vector3mm.y, DirtBlock.DIRT);

                                    }

                                }
                                else {
                                    world.setBlock(vector3mm.x, vector3mm.z, vector3mm.y, SimpleBlock.GRASS);
                                    world.setBlock(vector3mm.x, vector3mm.z + 1, vector3mm.y, PropertiesBlock.randomBlock());
                                    for (int i = 84; i < vector3mm.z; ++i) {
                                        world.setBlock(vector3mm.x, i, vector3mm.y, DirtBlock.DIRT);

                                    }

                                }

                            }
                            else if (pb.classificationMax == 6.0) { // BUILDING
                                IBlock iBlock;
                                IBlock iBlock2;
                                if (vector3mm.z <= 104) {
                                    iBlock = StoneBrickBlock.NORMAL;
                                    iBlock2 = StoneBrickBlock.NORMAL;
                                }
                                else {
                                    iBlock = PropertiesBlock.randomRoof();
                                    iBlock2 = SimpleBlock.BRICK_BLOCK;
                                }
                                world.setBlock(vector3mm.x, vector3mm.z, vector3mm.y, iBlock);
                                world.setBlock(vector3mm.x, vector3mm.z - 1, vector3mm.y, iBlock2);

                                for (int i = 84; i < vector3mm.z - 1; ++i) {

                                    if (((vector3mm.x % 4 == 0) || ((vector3mm.x + 1) % 4 == 0)) &&
                                            ((vector3mm.y % 4 == 0) || ((vector3mm.y + 1) % 4 == 0)) &&
                                            (i == 102 || i == 103 || i == 97 || i == 98 || i == 107 || i == 108)
                                    ) {
                                        world.setBlock(vector3mm.x, i, vector3mm.y, SimpleBlock.GLASS);
                                    }
                                    else {
                                        world.setBlock(vector3mm.x, i, vector3mm.y, StoneBrickBlock.NORMAL);

                                    }

                                }

                            }
                            else if (pb.classificationMax == 3.0) { // LOW VEGETATION
                                world.setBlock(vector3mm.x, vector3mm.z, vector3mm.y, new StainedBlock(new StainedBlock.StainedMaterial(Material.LEAVES, 1), StainedBlock.StainedColor.GREEN));

                            }
                            else if (pb.classificationMax == 4.0) { // AVERAGE VEGETATION
                                world.setBlock(vector3mm.x, vector3mm.z, vector3mm.y, new StainedBlock(new StainedBlock.StainedMaterial(Material.LEAVES, 1), StainedBlock.StainedColor.GREEN));

                            }
                            else if (pb.classificationMax == 5.0) { // HIGH VEGETATION
                                world.setBlock(vector3mm.x, vector3mm.z, vector3mm.y, new StainedBlock(new StainedBlock.StainedMaterial(Material.LEAVES, 1), StainedBlock.StainedColor.GREEN));

                            }
                            else if (pb.classificationMax == 0.0 && vector3mm.z <= 96){
                                world.setBlock(vector3mm.x, vector3mm.z, vector3mm.y, SimpleBlock.IRON_BLOCK);

                            }

                            // System.out.println(vector3mm);

                        }

                    }

                    //SortedSet<Vector3MM> keys = new TreeSet<>(points3mmProperties.keySet());
                    //for (Vector3MM key : keys) {
                        //PropertiesBlock value = points3mmProperties.get(key);
                        //System.out.println(key + " " + value);
                    //}

                    System.out.println("ILOSC " + points3mmProperties.size());






                    //  save the world
                    world.save();

                } catch (Throwable e) {
                    e.printStackTrace();
                }

                Platform.runLater(
                        () -> {
                            setCurrentWork(" READY :)");
                        }
                );
                return null;
            }



        };
    }


    public Boolean getCurrentState() {
        return currentState;
    }

    public void setCurrentState(Boolean stateNew) {
        this.currentState = stateNew;
    }

    public void setFiles(List<File> files) {
        this.files = files;
    }

    public void setPointsCount(long pointsCount) {
        this.pointsCount = pointsCount;
    }


    public ObjectProperty<String> currentWorkProperty() {
        return currentWork;
    }

    public final String getCurrentWork() {
        return currentWorkProperty().get();
    }

    public final void setCurrentWork(String currentWork) {
        currentWorkProperty().set(currentWork);
    }

    public long getPointsExportCount() {
        return pointsExportCount;
    }

    public void setPointsExportCount(long pointsExportCount) {
        this.pointsExportCount = pointsExportCount;
    }


    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    public long getMax() {
        return max;
    }

    public void setMax(long max) {
        this.max = max;
    }
}
