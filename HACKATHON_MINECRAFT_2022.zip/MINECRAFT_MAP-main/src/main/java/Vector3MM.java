import java.util.Locale;

public class Vector3MM implements Comparable<Vector3MM> {
    public int x;
    public int y;
    public int z;

    public Vector3MM(double x, double y, double z) {
        this.x = (int)x;
        this.y = (int)y;
        this.z = (int)z;

    }

    @Override
    public boolean equals(Object vector) {
        if (this == vector) {
            return true;
        }
        if (vector instanceof Vector3MM) {
            Vector3MM vector3mm = (Vector3MM)vector;
            return this.x == vector3mm.x && this.y == vector3mm.y && this.z == vector3mm.z;

        }
        return false;

    }

    @Override
    public String toString() {
        return String.format(Locale.US,"%d %d %d",  x, y, z);
    }

    @Override
    public int compareTo(Vector3MM vector) {
       int x = this.x - vector.x;
       if (x != 0) {
           return x;
       }
       x = this.y - vector.y;
        if (x != 0) {
            return x;
        }
        x = this.z - vector.z;
        return x;

    }

    @Override
    public int hashCode() {
        return (int)(x ^ (x >> 32) ^ y ^ (y >> 32) ^ z ^ (z >> 32));
    }

}
