package minmaxXY;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class minmaxXY {

    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("70017_811801_N-34-63-D-b-1-1-2-3.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                list.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        String[] firstLine = list.get(0).split(",");
        int xIndex = 0;
        int yIndex = 0;
        for (int i = 0; i < firstLine.length; i++) {
            if (firstLine[i].equals("X")) {
                xIndex = i;
            } else if (firstLine[i].equals("Y")) {
                yIndex = i;
            }
        }

        double minX = Double.MAX_VALUE;
        double maxX = Double.MIN_VALUE;
        double minY = Double.MAX_VALUE;
        double maxY = Double.MIN_VALUE;

        for (int i = 1; i < list.size(); i++) {
            String[] line = list.get(i).split(",");
            double x = Double.parseDouble(line[xIndex]);
            double y = Double.parseDouble(line[yIndex]);
            if (x < minX) {
                minX = x;
            }
            if (x > maxX) {
                maxX = x;
            }
            if (y < minY) {
                minY = y;
            }
            if (y > maxY) {
                maxY = y;
            }
        }

        try (FileWriter fw = new FileWriter("wyniki_minmax.txt")) {
            fw.write("minX: " + minX + "\n");
            fw.write("maxX: " + maxX + "\n");
            fw.write("minY: " + minY + "\n");
            fw.write("maxY: " + maxY + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}