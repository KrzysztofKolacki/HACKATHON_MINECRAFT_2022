package skala_v1;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class skala_v1 {

    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("70017_811801_N-34-63-D-b-1-1-2-3.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                list.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try (FileWriter fw = new FileWriter("wyniki_przeskalowane2.txt")) {
            for (int i = 1; i < list.size(); i++) {
                String[] split = list.get(i).split(",");
                double x = Double.parseDouble(split[0]);
                double y = Double.parseDouble(split[1]);
                double z = Double.parseDouble(split[2]);
                fw.write(Scale.scale(x, y, z) + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

//Stwórz klasę Scale
class Scale {
    public static String scale(double x, double y, double z) {
        return "X: " + x * 0.001 + " Y: " + y * 0.001 + " Z: " + z * 0.001;
    }
}