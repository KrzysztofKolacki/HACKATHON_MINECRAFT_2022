package intensity_v1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class intensity_v1 {

    public static void main(String[] args) {
        List<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("70017_811801_N-34-63-D-b-1-1-2-3.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        String[] header = lines.get(0).split(",");
        int intensityIndex = -1;
        for (int i = 0; i < header.length; i++) {
            if (header[i].equals("Intensity")) {
                intensityIndex = i;
                break;
            }
        }

        double min = Double.MAX_VALUE;
        double max = Double.MIN_VALUE;
        for (int i = 1; i < lines.size(); i++) {
            String[] line = lines.get(i).split(",");
            double intensity = Double.parseDouble(line[intensityIndex]);
            if (intensity < min) {
                min = intensity;
            }
            if (intensity > max) {
                max = intensity;
            }
        }

        try (FileWriter fw = new FileWriter("wyniki_Intensity.txt")) {
            fw.write("min: " + min + "\n");
            fw.write("max: " + max + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}